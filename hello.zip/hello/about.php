<?php

define( 'DVWA_WEB_PAGE_TO_ROOT', '' );
require_once DVWA_WEB_PAGE_TO_ROOT . 'dvwa/includes/dvwaPage.inc.php';

dvwaPageStartup( array( 'phpids' ) );

$page = dvwaPageNewGrab();
$page[ 'title' ]   = 'About' . $page[ 'title_separator' ].$page[ 'title' ];
$page[ 'page_id' ] = 'about';

$page[ 'body' ] .= "
<div class=\"body_padded\">
	<h2>About</h2>
	<br><h3> Cyber Security Society </h3><br>
	<p>  Cyber Security Society is a wellrecognized & registered organization with a mission of spreading awareness programs on new age technological crimes & frauds and safeguard people. We are facilitating and organizing multiple nationwide awareness programs, workshops, awareness trainings, conferences.</p>

	<p>Cyber Security Society is a well-recognized & registered organization with a mission of spreading awareness programs on new age technological crimes & frauds and safeguard people.</p>

	<p>We are working with a mission “We Make Best Effort to Ensure Your Privacy” and “Making Digital India Secure” to empower our country and citizens of our country. </p>
	
	<br> <h3> For more information visit: https://www.cybersecsociety.com/ </h3>

	
	<h3> Techtwins Technologies </h3>
	<p> Techtwins is a Premier, Full Service Software Development Company for Cloud Development Services, AI/ML, Cyber Security, BOTS, Mobile and Web Development with special focus on Timeliness, Security, Scale, and Performance.</p>

	<p>EXPERIENCE : EXCELLENCE : EXUBERANCE is our work mantra for Go-to-Market Strategy of our customers</p>

	<p>With a skilled workforce of 50+ team members, Techtwins is equally at ease of working with: Start-Ups, Small & Medium Enterprises, Large Enterprises, Development Sector, Public-Private Partnerships & Governments. More than 500+ projects in last 4+ years are a testimony to that.</p>

	<br><h3> For more information visit: https://www.techtwins.co.in/ </h3> 
</div>\n";

dvwaHtmlEcho( $page );

exit;

?>
